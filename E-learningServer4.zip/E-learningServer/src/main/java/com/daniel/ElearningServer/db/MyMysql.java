package com.daniel.ElearningServer.db;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class MyMysql {

    private QueryHandler queryHandler;

    public MyMysql(QueryHandler queryHandler) {
        this.queryHandler = queryHandler;
    }

    public void insertMedicineTreatmentData(Map<String, String> medicine) {
        String medicineName = medicine.get("name");
        int id = 0;
        if (medicineName != null) {
            id = getLastId("medicine_treatment");
            String data = checkIfRecordExists("medicine_treatment", medicineName);
            if (data.equals("brak danych") && id != -1) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date date;
                try {
                    date = simpleDateFormat.parse(medicine.get("startDate"));
                    StringBuilder sql = new StringBuilder();
                    sql.append("INSERT INTO medicine_treatment (id, name, dosage, tablets_taken" +
                            ", tablets_in_package, start_date) VALUES (" + id + ",'" + medicineName + "'" +
                            ", '" + medicine.get("dosage") + "', " + Integer.parseInt(medicine.get("tabletsTaken")) + ", " +
                            Integer.parseInt(medicine.get("tabletsInPackage")) + ", '" + simpleDateFormat.format(date) + "'");
                    sql.append(");");
                    queryHandler.execute(sql.toString());
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    }

    public void insertMedicineData(Map<String, Object> medi) {

        JSONObject medicine = new JSONObject(medi);
        int id = 0;

        String medicineName;
        medicineName = medicine.get("name").toString();
        if (medicineName != null) {
            id = getLastId("medicine");
            String data = checkIfRecordExists("medicine", medicineName);
            if (data.equals("brak danych") && id != -1) {
                StringBuilder sql = new StringBuilder();
                sql.append("INSERT INTO medicine (id, name,headline1, description1" +
                        ", headline2, description2, headline3, description3, headline4, description4" +
                        ", headline5, description5, headline6, description6, headline7, description7" +
                        ", headline8, description8, headline9, description9, headline10, description10" +
                        ", headline11, description11, headline12, description12, headline13, description13" +
                        ", headline14, description14, headline15, description15) VALUES (" + id + ",'" + medicineName + "'");

                int jsonLenght = medicine.length();
                int descriptionsAmount = medicine.length() - 2;
                JSONObject medicineDescription = null;

                for (int i = 1; i < jsonLenght; i++) {
                    medicineDescription = medicine.getJSONObject("description" + 1);
                    if (medicineDescription != null) {
                        sql.append(",'" + medicineDescription.get("headline").toString() + "','" + medicineDescription.get("content").toString() + "'");
                    }
                }
                if (descriptionsAmount < 15) {
                    for (int i = 1; i < 15 - descriptionsAmount; i++) {
                        sql.append(",'',''");
                    }
                }
                sql.append(");");
                queryHandler.execute(sql.toString());
            }

        }
    }

    public String checkIfRecordExists(String table, String name) {

        String description = null;
        List<Map<String, Object>> medicine;
        try {
            medicine = this.queryHandler.getByFunction("SELECT * FROM " + table + " WHERE name='" + name + "'");
        }catch (Exception e){
            description = "brak danych";
            return description;
        }

        if (medicine.size() > 0) {
            description = medicine.get(0).get("name").toString();
        } else {
            description = "brak danych";
        }
        return description;
    }

    private int getLastId(String table) {

        int id = 1;
        List<Map<String, Object>> medicine;

        try {
            medicine = this.queryHandler.getByFunction("SELECT * FROM " + table);
        } catch (Exception e) {
            id = -1;
            System.out.println(e);
            return id;
        }

        if (medicine.size() > 0) {
            for (Map map : medicine) {
                id++;
            }
        }
        return id;
    }
}