package com.daniel.ElearningServer.controller;

import com.daniel.ElearningServer.service.MedicineInfo;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class Controller {

    private MedicineInfo medicineInfo;

    public Controller(MedicineInfo medicineInfo) {
        this.medicineInfo = medicineInfo;
    }

    @RequestMapping(value = "/barcode", method = RequestMethod.POST)
    public List<String> getBarcode(@RequestBody Map<String, String> map){

        String barcode = map.get("barcode");
        return medicineInfo.getInformationAboutMedicine(barcode);

    }

}
