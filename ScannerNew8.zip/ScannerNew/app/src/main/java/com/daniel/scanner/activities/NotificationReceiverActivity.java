package com.daniel.scanner.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.daniel.scanner.R;

public class NotificationReceiverActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_receiver);
    }
}
