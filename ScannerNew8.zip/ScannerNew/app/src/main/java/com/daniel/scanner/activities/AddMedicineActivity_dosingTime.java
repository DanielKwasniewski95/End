package com.daniel.scanner.activities;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.icu.util.Calendar;
import android.inputmethodservice.Keyboard;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import com.daniel.scanner.R;
import com.daniel.scanner.sqlite.MysqLite;
import com.daniel.scanner.utilities.OuterServer;
import com.daniel.scanner.utilities.UserInput;

import java.util.*;

public class AddMedicineActivity_dosingTime extends AppCompatActivity {

    private Button saveButton;
    private int[] textViewIds;
    private OuterServer outerServer;
    private SQLiteDatabase sqLiteDatabase;
    private UserInput userInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medicine_dosing_time);

        RelativeLayout layout = findViewById(R.id.addMedicineDosingTimeLayout);
        layout.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View view, MotionEvent ev)
            {
                hideKeyboard(view);
                return false;
            }
        });

        this.saveButton = findViewById(R.id.saveButton);
        //get Tablets taken at once
        Intent intent = getIntent();
        final HashMap<String, String> medicineTreatmentInfoMap = (HashMap<String, String>)intent.getSerializableExtra("medicineTreatmentInfoMap");
        int tabletsTaken = Integer.parseInt(medicineTreatmentInfoMap.get("timesAday"));
        final String medicineName = medicineTreatmentInfoMap.get("name");

//        this.setTimeEditText = findViewById(R.id.setTimeEditText);
//
//        this.setTimeEditText.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Calendar cal = Calendar.getInstance();
//                int hour = cal.get(Calendar.HOUR);
//                int minute = cal.get(Calendar.MINUTE);
//
//                TimePickerDialog dialog = new TimePickerDialog(
//                        AddMedicineActivity_dosingTime.this,
//                        android.R.style.Theme_DeviceDefault_Light_Dialog_MinWidth,
//                        onTimeSetListener,
//                        hour,minute,true);
//                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
//                dialog.show();
//            }
//        });
//
//        onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
//            @Override
//            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
//                String time = hourOfDay + ":" + minute;
//                setTimeEditText.setText(time);
//            }
//        };

        //add time picker end

        // Get the widgets reference from XML layout
        RelativeLayout rl_addMedicine_dosingTime = findViewById(R.id.addMedicineDosingTimeLayout);
        final TextView[] textViews = new TextView[tabletsTaken];

        int i = 1;
        textViewIds = new int[tabletsTaken];
        for (TextView textView : textViews) {


            // Create a TextView programmatically.
            //final TextView textView = new TextView(getApplicationContext());
            textView = new TextView(getApplicationContext());

            textView.setId(View.generateViewId());

            // Create a LayoutParams for TextView
            RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.WRAP_CONTENT, // Width of TextView
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = 50;
            lp.topMargin = i * 100;

            // Apply the layout parameters to TextView widget
            textView.setLayoutParams(lp);

            // Set text to display in TextView
            textView.setHint("podaj czas przyjęcia leku - " + i);

            // Set a text color for TextView text
            textView.setTextColor(Color.parseColor("#ff0000"));

            // Add newly created TextView to parent view group (RelativeLayout)
            rl_addMedicine_dosingTime.addView(textView);
            this.textViewIds[i - 1] = textView.getId();
            i++;

            //add time picker to textView
            //textView1 = findViewById(textView.getId());
            addTimePicker(textView.getId());
        }

        this.userInput = new UserInput();
        this.saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Map<String, String> medicineTreatmentInfoDosingTime = new LinkedHashMap<>();
                Map<String, String> medicineTreatmentInfoDosingTimeTakenCheck = new LinkedHashMap<>();
                int i = 1;

                medicineTreatmentInfoDosingTime.put("name", medicineName);
                medicineTreatmentInfoDosingTimeTakenCheck.put("name", medicineName);
                for (int id : textViewIds) {
                    final TextView textView = findViewById(id);
                    medicineTreatmentInfoDosingTime.put("dosing_time_" + i, textView.getText().toString());
                    medicineTreatmentInfoDosingTimeTakenCheck.put("dosing_time_" + i + "_taken_check", "false");
                    i++;
                }

//                JSONObject jsonObject = new JSONObject(medicineTreatmentInfoDosingTime);
//                outerServer = new OuterServer();
//                outerServer.sendMedicineTreatmentDataDosingTime(jsonObject);
                if (userInput.doesUserFilledAllInputs(medicineTreatmentInfoDosingTime)) {

                    sqLiteDatabase = getApplicationContext().openOrCreateDatabase("e-learning", MODE_PRIVATE, null);
                    MysqLite.insertMedicineForTreatment(sqLiteDatabase, medicineTreatmentInfoMap);

                    MysqLite.insertMedicineTreatmentDosingTimeData(sqLiteDatabase, medicineTreatmentInfoDosingTime);
                    MysqLite.insertMedicineTreatmentDosingTimeDataTakenCheck(sqLiteDatabase, medicineTreatmentInfoDosingTimeTakenCheck);

                    //Map<String, String> list = MysqLite.readData(sqLiteDatabase, "SELECT * FROM medicine_treatment_dosing_time_taken_check");
                    if (sqLiteDatabase.isOpen()) {
                        sqLiteDatabase.close();
                    }

                    Intent intent = new Intent(AddMedicineActivity_dosingTime.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Proszę wypełnić wszystkie pola", Toast.LENGTH_LONG).show();
                }
            }
        });
        //addTimePicker(textViewIds);
    }

    private void addTimePicker(final int id) {

        final TimePickerDialog.OnTimeSetListener test = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hour, int minute) {

                String hourString = String.valueOf(hour);
                String minuteString = String.valueOf(minute);
                if (hourString.length() == 1) {
                    hourString = "0" + hourString;
                }
                if (minuteString.length() == 1) {
                    minuteString = "0" + minuteString;
                }

                String time = hourString + ":" + minuteString;
                final TextView textView = findViewById(id);
                textView.setText(time);
            }
        };

        final TextView textView = findViewById(id);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int hour = cal.get(Calendar.HOUR);
                int minute = cal.get(Calendar.MINUTE);

                TimePickerDialog dialog = new TimePickerDialog(
                        AddMedicineActivity_dosingTime.this,
                        R.style.PickerDialogTheme,
                        test,
                        hour, minute, true);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();

            }
        });

//        for (int i = 0; i < textViewIds.length; i++) {
//            final TextView textView = findViewById(textViewIds[i]);
//            textView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    Calendar cal = Calendar.getInstance();
//                    int hour = cal.get(Calendar.HOUR);
//                    int minute = cal.get(Calendar.MINUTE);
//
//                    TimePickerDialog dialog = new TimePickerDialog(
//                            AddMedicineActivity_dosingTime.this,
//                            android.R.style.Theme_DeviceDefault_Light_Dialog_MinWidth,
//                            onTimeSetListener,
//                            hour, minute, true);
//                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
//                    dialog.show();
//
//                }
//            });
//
//            onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
//                @Override
//                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
//                    String time = hourOfDay + ":" + minute;
//                    textView.setText(time);
//                }
//            };
//
//        }
    }
    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
