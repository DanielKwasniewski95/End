package com.daniel.ElearningServer.service;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class MedicineInfo {

    public static final String GOOGLE_SEARCH_URL = "https://www.google.com/search";
    public static final String MEDICINES_WEB_DATABASE = "https://bazalekow.mp.pl/leki/szukaj.html?item_name=";

    private String getName(String searchTerm){
        //Taking search term input from console
      /*  Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the search term.");
        String searchTerm = scanner.nextLine();*/
        /*System.out.println("Please enter the number of results. Example: 5 10 20");
        int num = scanner.nextInt();
        scanner.close();*/

        String searchURL = GOOGLE_SEARCH_URL + "?q="+searchTerm+"&num=1";
        //without proper User-Agent, we will get 403 error
        Document doc = null;
        try {
            doc = Jsoup.connect(searchURL).userAgent("GoogleChrome").get();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //below will print HTML data, save it to a file and open in browser to compare
        //System.out.println(doc.html());

        //If google search results HTML change the <h3 class="r" to <h3 class="r1"
        //we need to change below accordingly
        Elements results = doc.select("h3.r > a");


        /*for (Element result : results) {
            String linkHref = result.attr("href");
            String linkText = result.text();
            System.out.println(linkText);
        }*/
        String nameOfMedicine = "";
        if(results.size()>0) {
            nameOfMedicine = (String)results.get(0).text().subSequence(0,results.get(0).text().indexOf(" "));
        }

        return nameOfMedicine;
    }

    private String getSubLinks(String medicine) {
        Document doc = null;
        try {
            doc = Jsoup.connect("https://bazalekow.mp.pl/leki/szukaj.html?item_name=" + medicine).get();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Elements itemFound = doc.select("ul.item-found > li > a");
     /*   for (Element element : itemFound) {
            System.out.println(element.toString().subSequence(element.toString().indexOf("\"") + 1, element.toString().indexOf(">") - 1));
        }*/
     try{
         return (String) itemFound.get(0).toString().subSequence(itemFound.get(0).toString().indexOf("\"") + 1, itemFound.get(0).toString().indexOf(">") - 1);
     }catch (Exception e){
         return "";
     }

    }

    public List<String> getInformationAboutMedicine(String scanResult){

        String medicineName = getName(scanResult);
        String url = getSubLinks(medicineName);

        String searchURL = url;
        Document doc = null;
        try {
            doc = Jsoup.connect(searchURL).get();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements results = doc.select("h2");
        Elements results2 = doc.select("div.item-content");
        /*System.out.println(results.size());
        System.out.println(results2.size());*/
        for (int i=0;i<results.size();i++) {
            if(results.get(i).text().equals("")){
                results.remove(i);
            }
        }
        //results.remove(0);

        int removeValue = results.size() - results2.size();
        if(removeValue>0) {
            for (int i = results.size()-1; i >= results2.size(); i--) {

                results.remove(i);

            }
        }

        List<String> medicinePropertiesList = new ArrayList<String>();
        for(int i=0;i<results.size();i++) {
            medicinePropertiesList.add(results.get(i).text() + "\n" + results2.get(i).text());
            //medicinePropertiesList.add(results2.get(i).text());
            medicinePropertiesList.add("*******************");

        }
        StringBuilder builder = new StringBuilder();
        for (String details : medicinePropertiesList) {
            builder.append(details + "\n");
        }

        //MainActivity.propertiesView.setText(builder.toString());
        //System.out.println(results.get().text());

        return medicinePropertiesList;

    }

}
