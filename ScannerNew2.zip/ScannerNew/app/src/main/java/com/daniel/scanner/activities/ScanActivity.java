package com.daniel.scanner.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import com.daniel.scanner.Medicine;
import com.google.zxing.Result;
import me.dm7.barcodescanner.zxing.ZXingScannerView;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class ScanActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {

    private ZXingScannerView scannerView;
    private Medicine medicine;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        scannerView = new ZXingScannerView(this);   // Programmatically initialize the scanner view
        setContentView(scannerView);                // Set the scanner view as the content view
    }

    @Override
    public void onResume() {
        super.onResume();
        scannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
        scannerView.startCamera();          // Start camera on resume
    }

    @Override
    public void onPause() {
        super.onPause();
        scannerView.stopCamera();           // Stop camera on pause
    }

    @Override
    public void handleResult(Result rawResult) {
        // Do something with the result here
        // Log.v("tag", rawResult.getText()); // Prints scan results
        // Log.v("tag", rawResult.getBarcodeFormat().toString()); // Prints the scan format (qrcode, pdf417 etc.)

        //MainActivity.tvresult.setText(rawResult.getText());
        this.medicine = new Medicine();
        onBackPressed();

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("code", rawResult);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
        /*    URL url = new URL("http://192.168.0.101:8080/barcode");
            //Open the connection here, and remember to close it when job its done.
            URLConnection conn = url.openConnection();
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            //theJSONYouWantToSend should be the JSONObject as String
            wr.write(jsonObject.toString());  //<--- sending data.

            wr.flush();

            BufferedReader serverAnswer = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            String result = "";
            while ((line = serverAnswer.readLine()) != null) {

                result += line; //<--If any response from server
                //use it as you need, if server send something back you will get it here.
            }*/
            Toast.makeText(this, rawResult.getText(), Toast.LENGTH_LONG).show();
            //MainActivity.tvresult.setText(getInformationAboutMedicine(getSubLinks(getName(rawResult.toString()))));

            List<String> medicinePropertiesList = medicine.getInformationAboutMedicine(rawResult.toString());

            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_list_item_1,
                    medicinePropertiesList );

            MainActivity.setListView(arrayAdapter);
            //wr.close();
        }catch (Exception e){
            Log.i("exc", e.toString());
            Toast.makeText(this, "Please check your internet connection.", Toast.LENGTH_LONG).show();
        }

        // If you would like to resume scanning, call this method below:
        //scannerView.resumeCameraPreview(this);
    }
}

