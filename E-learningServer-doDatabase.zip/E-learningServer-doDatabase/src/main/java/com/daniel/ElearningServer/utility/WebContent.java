package com.daniel.ElearningServer.utility;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import javax.print.Doc;
import java.io.IOException;

@Service
public class WebContent {

    private SslFactory sslFactory;

    public static final String GOOGLE_SEARCH_URL = "https://www.google.com/search";
    public static final String OPEN_PHARMACY = "https://openpharmacy.pl/?s=";
    public static final String MEDICINES_WEB_DATABASE = "https://bazalekow.mp.pl/leki/szukaj.html?item_name=";
    public static final String MEDICINES_WEB_DATABASE_2 = "https://www.lekinfo24.pl/wyniki-wyszukiwania?qh=";

    public WebContent(SslFactory sslFactory) {
        this.sslFactory = sslFactory;
    }

    public Document search(String type, String urlContent) {
        String searchURL = urlContent;

        Document doc = null;
        boolean done = false;

        while (!done) {
            try {
                doc = Jsoup.connect(searchURL).userAgent("Chrome/77.0.3865.90").sslSocketFactory(sslFactory.socketFactory()).timeout(20 * 1000).get();
                done = true;
            } catch (IOException e) {
                e.printStackTrace();
                String x = "";
                done = false;
            }
        }

        return doc;
    }

}
