package com.daniel.ElearningServer.db;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by Daniel K.
 */

@Component
public class QueryHandler {

    private JdbcTemplate jdbcTemplate;

    public QueryHandler(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Map<String, Object>> getByFunction(String sql_querry) {
        return this.jdbcTemplate.queryForList(sql_querry);
    }

    public void execute(String sql_querry) {
        jdbcTemplate.execute(sql_querry);
    }

}
