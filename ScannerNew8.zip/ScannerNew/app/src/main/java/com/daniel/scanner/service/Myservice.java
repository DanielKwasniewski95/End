package com.daniel.scanner.service;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;
import com.daniel.scanner.R;
import com.daniel.scanner.activities.AddMedicineActivity;
import com.daniel.scanner.sqlite.MysqLite;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Myservice extends Service {

    private SQLiteDatabase sqLiteDatabase;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        //TODO do something useful
        final Handler mHandler = new Handler();
        final Runnable myTask = new Runnable() {
            public void run() {
                try {
                    sqLiteDatabase = getApplicationContext().openOrCreateDatabase("e-learning", MODE_PRIVATE, null);

                    Map<String, String> list = MysqLite.readData(sqLiteDatabase, "SELECT * FROM medicine_treatment");
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    Date dateNow = new Date();
                    dateNow = sdf.parse(sdf.format(dateNow));
                    Date medicineStartTakenDate = sdf.parse(list.get("start_date"));
                    if (dateNow.compareTo(medicineStartTakenDate) <= 0) {
                        Map<String, String> list2 = MysqLite.readData(sqLiteDatabase, "SELECT * FROM medicine_treatment_dosing_time");
                        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm");
                        Date timeNow = new Date();
                        timeNow = sdf2.parse(sdf2.format(timeNow));
                        Date medicineTimeTaken1 = sdf2.parse(list2.get("dosing_time_1"));
                        Date medicineTimeTaken2 = sdf2.parse(list2.get("dosing_time_2"));

                        Map<String, String> list3 = MysqLite.readData(sqLiteDatabase, "SELECT * FROM medicine_treatment_dosing_time_taken_check");
                        boolean medicineTaken1;
                        boolean medicineTaken2;
                        medicineTaken1 = Boolean.parseBoolean(list3.get("dosing_time_1_taken"));
                        medicineTaken2 = Boolean.parseBoolean(list3.get("dosing_time_2_taken"));
                        Intent intent2 = new Intent(getApplicationContext(), AddMedicineActivity.class);
                        Intent intent3 = new Intent(getApplicationContext(), AddMedicineActivity.class);

                        while (true) {
                            if (timeNow.compareTo(medicineTimeTaken1) == 0 && medicineTaken1 == false) {
                                medicineTaken1 = true;
                                showNotification(getApplicationContext(), "notification", list.get("name"), intent2);
                                sqLiteDatabase.execSQL("UPDATE medicine_treatment_dosing_time_taken_check SET dosing_time_1_taken = 'true' WHERE id = 1");
                            }
                            if (timeNow.compareTo(medicineTimeTaken2) == 0 && medicineTaken2 == false) {
                                medicineTaken2 = true;
                                showNotification(getApplicationContext(), "notification2", list.get("name"), intent3);
                                sqLiteDatabase.execSQL("UPDATE medicine_treatment_dosing_time_taken_check SET dosing_time_2_taken = 'true' WHERE id = 1");
                                if (sqLiteDatabase.isOpen()) {
                                   sqLiteDatabase.close();
                               }
                                break;
                            }
                            timeNow = new Date();
                            timeNow = sdf2.parse(sdf2.format(timeNow));
                        }
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        };
        //myTask.run();
        mHandler.post(myTask);
        //mHandler.postDelayed(myTask, 1000);

        //mHandler.removeCallbacks(myTask);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //Toast.makeText(this, "Service Destroyed", Toast.LENGTH_LONG).show();

//        Intent broadcastIntent = new Intent("ac.in.ActivityRecognition.RestartSensor");
//        sendBroadcast(broadcastIntent);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);

//        Toast.makeText(this, "Service started again", Toast.LENGTH_LONG).show();
//        Intent broadcastIntent = new Intent("ac.in.ActivityRecognition.RestartSensor");
//        sendBroadcast(broadcastIntent);
    }

    public void showNotification(Context context, String title, String body, Intent intent) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        Date now = new Date();
        int notificationId = Integer.parseInt(new SimpleDateFormat("ddHHmmss", Locale.UK).format(now));
        String channelId = "channel-01";
        String channelName = "Channel Name";
        int importance = NotificationManager.IMPORTANCE_HIGH;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel(
                    channelId, channelName, importance);
            notificationManager.createNotificationChannel(mChannel);
        }

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setAutoCancel(true)
                .setContentText(body);

        TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
        stackBuilder.addNextIntent(intent);
        PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(
                0,
                PendingIntent.FLAG_UPDATE_CURRENT
        );
        mBuilder.setContentIntent(resultPendingIntent);

        notificationManager.notify(notificationId, mBuilder.build());
    }

//    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//    Date date1 = null;
//    Date date2 = null;
//try {
//        date1 = sdf.parse("2010-01-31");
//        date2 = sdf.parse("2010-01-31");
//    }catch (Exception e) {
//        e.printStackTrace();
//    }
//
//System.out.println("date1 : " + sdf.format(date1));
//System.out.println("date2 : " + sdf.format(date2));
//
//if (date1.compareTo(date2) > 0) {
//        System.out.println("Date1 is after Date2");
//    } else if (date1.compareTo(date2) < 0) {
//        System.out.println("Date1 is before Date2");
//    } else if (date1.compareTo(date2) == 0) {
//        System.out.println("Date1 is equal to Date2");
//    } else {
//        System.out.println("How to get here?");
//    }
//
//    SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm");
//    Date time1 = null;
//    Date time2 = null;
//try {
//        time1 = sdf2.parse("10:00");
//        time2 = sdf2.parse("10:01");
//    }catch (Exception e) {
//        e.printStackTrace();
//    }
//
//System.out.println("time1 : " + sdf2.format(time1));
//System.out.println("time2 : " + sdf2.format(time2));
//
//if (time1.compareTo(time2) > 0) {
//        System.out.println("Time1 is after Time2");
//    } else if (time1.compareTo(time2) < 0) {
//        System.out.println("Time1 is before Time2");
//    } else if (time1.compareTo(time2) == 0) {
//        System.out.println("Time1 is equal to Time2");
//    } else {
//        System.out.println("How to get here?");
//    }
}
