package com.daniel.scanner.sqlite;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class MysqLite {

    public static void insertMedicineForTreatment(SQLiteDatabase sqLiteDatabase, Map<String, String> map) {

        String medicineName = map.get("name");
        int id = 0;
        if (medicineName != null) {
            id = getLastId(sqLiteDatabase, "medicine_treatment");
            String data = checkIfMedicineInfoExists(sqLiteDatabase, "medicine_treatment", medicineName);
            if (data.equals("brak danych") && id != -1) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date date;
                try {
                    date = simpleDateFormat.parse(map.get("startDate"));
                    StringBuilder sql = new StringBuilder();
                    sql.append("INSERT INTO medicine_treatment (id, name, dosage, tablets_taken" +
                            ", tablets_in_package, start_date) VALUES (" + id + ",'" + medicineName + "'" +
                            ", '" + map.get("dosage") + "', " + Integer.parseInt(map.get("tabletsTaken")) + ", " +
                            Integer.parseInt(map.get("tabletsInPackage")) + ", '" + simpleDateFormat.format(date) + "'");
                    sql.append(");");
                    sqLiteDatabase.execSQL(sql.toString());
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    }

    public static void insertMedicineInfoData(SQLiteDatabase sqLiteDatabase, JSONObject medicine) {

        String medicineName = null;
        int id = 0;
        try {
            medicineName = medicine.get("name").toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (medicineName != null) {
            id = getLastId(sqLiteDatabase, "medicine");
            String data = checkIfMedicineInfoExists(sqLiteDatabase, "medicine", medicineName);
            if (data.equals("brak danych") && id != -1) {
                id = getLastId(sqLiteDatabase, "medicine");
                StringBuilder sql = new StringBuilder();
                sql.append("INSERT INTO medicine (id, name,headline1, description1" +
                        ", headline2, description2, headline3, description3, headline4, description4" +
                        ", headline5, description5, headline6, description6, headline7, description7" +
                        ", headline8, description8,  headline9, description9, headline10, description10" +
                        ", headline11, description11, headline12, description12, headline13, description13" +
                        ", headline14, description14, headline15, description15) VALUES (" + id + ",'" + medicineName + "'");

                int jsonLenght = medicine.length();
                int descriptionsAmount = medicine.length() - 2;
                JSONObject medicineDescription = null;

                for (int i = 1; i < jsonLenght; i++) {
                    try {
                        medicineDescription = medicine.getJSONObject("description" + i);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if (medicineDescription != null) {
                        try {
                            sql.append(",'" + medicineDescription.get("headline").toString() + "','" + medicineDescription.get("content").toString() + "'");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (descriptionsAmount < 15) {
                    for (int i = 1; i < 15 - descriptionsAmount; i++) {
                        sql.append(",'',''");
                    }
                }
                sql.append(");");
                sqLiteDatabase.execSQL(sql.toString());
            }
        }
    }

    public static String checkIfMedicineInfoExists(SQLiteDatabase sqLiteDatabase, String table, String name) {

        String description = null;
        Cursor data = null;
        try {
            data = sqLiteDatabase.rawQuery("SELECT * FROM " + table + " WHERE name='" + name + "'", null);
        } catch (Exception e) {
            System.out.println(e);
        }

        if (data != null && data.getCount() != 0) {
            data.moveToFirst();
            description = data.getString(data.getColumnIndex("name"));
        } else {
            description = "brak danych";
        }
        return description;
    }

    public static int getLastId(SQLiteDatabase sqLiteDatabase, String table) {
        int id = 1;
        Cursor data = null;
        try {
            data = sqLiteDatabase.rawQuery("SELECT * FROM " + table, null);
        } catch (Exception e) {
            id = -1;
            System.out.println(e);
            return id;
        }

        if (data != null && data.getCount() != 0) {
            data.moveToFirst();
            id = 1;
            while (data.moveToNext()) {
                id++;
            }
        } else {
            return id;
        }
        return id;
    }
}
