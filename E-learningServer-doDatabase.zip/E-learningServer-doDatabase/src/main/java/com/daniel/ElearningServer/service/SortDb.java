package com.daniel.ElearningServer.service;

import com.daniel.ElearningServer.db.MyMysql;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class SortDb {

    private MyMysql mysql;

    public SortDb(MyMysql mysql) {
        this.mysql = mysql;
    }

    public Map createMapForInsert() {
        //char[] alphabetAndNumbers = "aąbcćdeęfghijklłmnńoóprsśtuwyzźż1234567890".toCharArray();
        Map<String, Object> medicineInformation = new LinkedHashMap<>();
        try {
            char[] alphabetAndNumbers = "1234567890".toCharArray();

            Map<String, Object> medicine = new LinkedHashMap<>();
            int medInfSize = 0;

            // czy jest id
            Map<String, Object> listByLetter = new LinkedHashMap<>();
            ArrayList<String> headlines = new ArrayList<>();
            ArrayList<String> descriptions = new ArrayList<>();
            List<Map<String, Object>> allList = new ArrayList<>();
            for (int x=1; x<=3; x++) {
                if (x==1) {
                    allList = this.mysql.getDataWithDescription("medicine");
                } else {
                    allList = this.mysql.getDataWithDescription("medicine" + x);
                }
                for (char charElement : alphabetAndNumbers) {
                    for (Map map : allList) {
                        medicineInformation = new LinkedHashMap<>();
                        medicine = new LinkedHashMap<>();
//                String n = map.get("name").toString().substring(0, 1).toLowerCase();
//                if (n.charAt(0) == charElement) {
//                    String p = "";
//                }
                        if (map.get("name").toString().substring(0, 1).toLowerCase().charAt(0) == charElement) {
                            for (Object str : map.keySet()) {
                                if (map.get((String) str) != null) {
                                    if (!map.get((String) str).equals("")) {
                                        medInfSize++;
                                    }
                                }
                            }
                            if (medInfSize != 0) {
                                medInfSize -= 2;
                                medInfSize /= 2;
                            }
                            for (int i = 1; i <= medInfSize; i++) {
                                headlines.add(map.get("headline" + i).toString());
                                descriptions.add(map.get("description" + i).toString());
                            }
                            medicineInformation.put("name", map.get("name"));
                            for (int i = 0; i < headlines.size(); i++) {
                                medicine = new LinkedHashMap<>();
                                medicine.put("headline", headlines.get(i));
                                medicine.put("content", descriptions.get(i));
                                medicineInformation.put("description" + (i + 1), medicine);
                            }
                        }
                        if (medicineInformation.size() > 0) {
                            this.mysql.insertMedicineData(medicineInformation, "medicineselse");
                        }
                        headlines.clear();
                        descriptions.clear();
                        medInfSize = 0;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            String x ="";
        }

        return medicineInformation;
    }
}
