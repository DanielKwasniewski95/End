package com.daniel.scanner.activities;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import com.daniel.scanner.R;
import com.daniel.scanner.sqlite.MysqLite;
import com.daniel.scanner.utilities.OuterServer;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class AddMedicineActivity extends AppCompatActivity {

    private Spinner dosageSpinner;
    private EditText medicineNameEditText;
    private EditText numberOfTabletsTaken;
    private EditText numberOfTabletsInPackage;
    private EditText startDateEditText;
    private Button saveButton;
    private static final String[] dosageList = {"daily", "weekly", "monthly"};

    private SQLiteDatabase sqLiteDatabase;
    private OuterServer outerServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medicine);

        this.dosageSpinner = findViewById(R.id.dosageSpinner);
        this.medicineNameEditText = findViewById(R.id.medicineNameEditText);
        this.numberOfTabletsTaken = findViewById(R.id.numberOfTabletsTaken);
        this.numberOfTabletsInPackage = findViewById(R.id.numberOfTabletsInPackage);
        this.startDateEditText = findViewById(R.id.startDateEditText);
        this.saveButton = findViewById(R.id.saveButton);

        /*SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        this.startDateEditText = new Date();
        try{
            this.startDateEditText = dateFormat.parse(findViewById(R.id.startDateEditText).toString());
        } catch (Exception e){
            System.out.println(e);
        }*/

        //fillDosageSpinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(AddMedicineActivity.this,
                android.R.layout.simple_spinner_item, this.dosageList);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.dosageSpinner.setAdapter(adapter);
        //fillDosageSpinner

        //hide keyboard for all editText
        this.medicineNameEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });
        //hide keyboard for all editText

        try {
            sqLiteDatabase = this.openOrCreateDatabase("e-learning", MODE_PRIVATE, null);

        } catch (Exception e) {
            Log.i("sql", e.toString());
        }

        this.saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, String> medicineTreatmentInfo = new LinkedHashMap<>();
                medicineTreatmentInfo.put("name", medicineNameEditText.getText().toString());
                medicineTreatmentInfo.put("dosage", dosageSpinner.getSelectedItem().toString());
                medicineTreatmentInfo.put("tabletsTaken", numberOfTabletsTaken.getText().toString());
                medicineTreatmentInfo.put("tabletsInPackage", numberOfTabletsInPackage.getText().toString());
                medicineTreatmentInfo.put("startDate", startDateEditText.getText().toString());
                MysqLite.insertMedicineForTreatment(sqLiteDatabase, medicineTreatmentInfo);
                JSONObject jsonObject = new JSONObject(medicineTreatmentInfo);
                outerServer = new OuterServer();
                outerServer.sendMedicineTreatmentData(jsonObject);
                sqLiteDatabase.close();
                Intent intent = new Intent(AddMedicineActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
