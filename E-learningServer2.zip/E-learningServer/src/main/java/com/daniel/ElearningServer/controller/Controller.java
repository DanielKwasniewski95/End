package com.daniel.ElearningServer.controller;

import com.daniel.ElearningServer.service.MedicineInfo;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class Controller {

    private MedicineInfo medicineInfo;

    public Controller(MedicineInfo medicineInfo) {
        this.medicineInfo = medicineInfo;
    }

    @RequestMapping(value = "/barcode", method = RequestMethod.POST)
    public Map<String, Object> getBarcode(@RequestBody Map<String, String> map){

        String barcode = map.get("barcode");
        //JSONObject jb = medicineInfo.getInformationAboutMedicine(barcode);

        return medicineInfo.getInformationAboutMedicine(barcode);

    }

}
