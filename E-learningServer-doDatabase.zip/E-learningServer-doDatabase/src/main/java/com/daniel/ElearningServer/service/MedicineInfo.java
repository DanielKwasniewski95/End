package com.daniel.ElearningServer.service;

import com.daniel.ElearningServer.db.MyMysql;
import com.daniel.ElearningServer.utility.SslFactory;
import com.daniel.ElearningServer.utility.WebContent;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.*;

@Service
public class MedicineInfo {

    private MyMysql mysql;

    private String medicineFullName = "";
    private String searchedMedicineName = "";

    public MedicineInfo(MyMysql mysql) {
        this.mysql = mysql;
    }

    private String getName(String searchType, String searchTerm) {

        WebContent webContent = new WebContent(new SslFactory());
        Document doc = null;
        String medicineName = "";

        doc = webContent.search(searchType, searchTerm);

        Elements results = doc.select("h3.LC20lb");

        try {
            if (results.size() == 0) {
                //searchAgain
                results = doc.select("h2.post-title > a");
            }
            if (results.size() > 0) {
                String[] result = results.get(0).text().split(" ");
                if (!result[0].equals("-") && !result[1].equals("-") && !result[2].equals("-"))
                    medicineName = result[0] + " " + result[1] + " " + result[2];
                else if (!result[0].equals("-") && !result[1].equals("-") && result[2].equals("-")) {
                    medicineName = result[0] + " " + result[1];
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return medicineName;
    }

    public ArrayList<String> getSubLinks(int database) {

        Document doc = null;
        //char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        char[] alphabet = "a".toCharArray();
        String subLink = "";
        String subLinks = "";
        ArrayList<String> allLinks = new ArrayList();

        //for (char letter : alphabet) {
        for (int number = 1; number <= 951; number++) {
            System.out.println(number);
            WebContent webContent = new WebContent(new SslFactory());
            //doc = webContent.search("sublinks", "https://www.mp.pl/pacjent/leki/items.html?letter=" + letter);
            doc = webContent.search("sublinks", "https://www.doz.pl/apteka/szukaj/s3_" + number + "-Apteka?search=");
            //subLinks = doc.select("script").get(7);
            subLinks = doc.getElementsByTag("script").get(7).toString(); //jakby nie ten skrypt
            if (!subLinks.equals("")) {
                if (subLinks.contains("url")) {
                    subLinks = subLinks.substring(subLinks.indexOf("var productsArray = [") + 18);
                    subLinks = subLinks.substring(subLinks.indexOf("{"), subLinks.indexOf("]") + 1);
                    if (!subLinks.substring(0, 1).equals("[")) {
                        subLinks = "[" + subLinks;
                    }
                    if (subLinks.contains("url")) {
                        try {
                            JSONArray array = new JSONArray(subLinks);
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject jsonObject = array.getJSONObject(i);
                                allLinks.add(jsonObject.getString("url") + "\n");
                                String all = allLinks.toString();
                                try {
                                    BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\Toshiba\\Desktop\\links.txt"));
                                    writer.write(all);

                                    writer.close();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    String x = "";
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            String x = "";
                        }
                    } else {
                        String x = "";
                    }
                } else {
                    String x = "";
                }

            }
            //subLinks = doc.select("ul.lista-handlowe > li > a");
            //allLinks.addAll(subLinks);
        }
        //}

        String all = allLinks.toString();
        return allLinks;
    }

    private String findSubLinksWithShorterMedicineName(int database, boolean withoutScan) {
        String url = "";
        searchedMedicineName = getShorterName(searchedMedicineName);
        //url = getSubLinks(database);
        if (!withoutScan) {
            medicineFullName = searchedMedicineName;
        }
        return url;
    }

    private String searchDatabaseAgainIfPossible(String url, int medicineWebDatabase, boolean withoutScan) {
        if (url.isEmpty()) {
            url = findSubLinksWithShorterMedicineName(medicineWebDatabase, withoutScan);
        }
        if (searchedMedicineName.contains(" ")) {
            if (url.isEmpty()) {
                url = findSubLinksWithShorterMedicineName(medicineWebDatabase, withoutScan);
            }
        }
        return url;
    }

    public Map<String, Object> getInformationAboutMedicine(String link) {

        String url = "";
        Elements headlines = null;
        //searching in first web database
        //ArrayList<String> links =
        //getSubLinks(1);
        ArrayList<String> links = new ArrayList<String>();
        try {
            File file = new File("C:\\Users\\Toshiba\\Desktop\\links.txt");

            BufferedReader br = new BufferedReader(new FileReader(file));

            String st;
            while ((st = br.readLine()) != null) {
                //System.out.println(st.replaceAll(",", "").trim());
                links.add(st.replaceAll(",", "").trim());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Document doc = null;
        Map<String, Object> medicineFirstHeadline = new LinkedHashMap<>();
        ArrayList<String> descriptions2 = new ArrayList<>();
        boolean strongAppeard = false;

        List<Map<String, Object>> withDescription = this.mysql.getDataWithDescription("medicine");
        List<Map<String, Object>> withDescription2 = this.mysql.getDataWithDescription("medicine2");
        //List<Map<String, Object>> withoutDescription = this.mysql.getDataWithoutDescription();

        ArrayList<String> withDescNames = new ArrayList<>();
        ArrayList<String> withDescNames2 = new ArrayList<>();
        //ArrayList<String> withoutDescNames = new ArrayList<>();

        for (Map map : withDescription) {
            withDescNames.add(map.get("name").toString().toLowerCase());
        }

        for (Map map : withDescription2) {
            withDescNames2.add(map.get("name").toString().toLowerCase());
        }

        WebContent webContent = new WebContent(new SslFactory());
        int linksSize = 19963;
        for (String element : links) {
            boolean contentWas = false;
            System.out.println(linksSize);
            if (linksSize == 10769) {
                String a = "";
                //}
                Elements descriptions = new Elements();
                try {
                    if (webContent == null) {
                        webContent = new WebContent(new SslFactory());
                    }
//                String suburl = element.attr("href");
                    url = "https://www.doz.pl" + element;
                    //String url = "https://www.lekinfo24.pl" + suburl;
                    doc = webContent.search("medicineInformation", url);

                    medicineFullName = doc.select("div.product_title > h1").text().replaceAll("'", "");
                    if (medicineFullName.contains("Aspirator")) {
                        String p = "";
                    }
//                headlines = doc.select("h2");
//                descriptions = doc.select("div.item-content");

//                medicineFullName = doc.select("div.opis-leku-pacjent-head > h2").text();
                    headlines = doc.select("div.editor-content > h2 > b");


                    if (!medicineFullName.equals("")) {
                        if (headlines != null) {
                            boolean doRecord = false;
                            String medicineFullNameLowerCase = medicineFullName.toLowerCase();

                            if (checkIfListsFromDatabaseContainMedicineName(withDescNames, medicineFullNameLowerCase) && checkIfListsFromDatabaseContainMedicineName(withDescNames2, medicineFullNameLowerCase)) {
                                doRecord = false;
                            } else {
                                doRecord = true;
                            }
                            if (doRecord) {
                                if (headlines.size() > 0) {


                                    int headlinesSize = headlines.size();
                                    descriptions = doc.select("h2#sec_1");
                                    boolean secOk = false;
                                    if (descriptions.size() > 0) {
                                        for (int i = 0; i < headlinesSize; i++) {
                                            try {
                                                doc.select("h2#sec_" + (i + 1)).first().nextElementSibling();
                                                secOk = true;
                                                descriptions = new Elements();
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                                secOk = false;
                                                descriptions = new Elements();
                                                break;
                                            }
                                        }
                                    }
                                    Element desc = doc.select("div.editor-content").first();
                                    contentWas = true;
                                    String toAdd = "";
                                    int index = 0;
                                    boolean strongElementAppeared = false;
                                    descriptions2.clear();
                                    for (Node child : desc.childNodes()) {
                                        if (!child.toString().trim().isEmpty()) {
                                            if (child.toString().contains("<h2")) {
                                                strongElementAppeared = true;
                                                if (!toAdd.equals("")) {
                                                    descriptions2.add(toAdd);
                                                    toAdd = "";
                                                }
                                            }
                                            if (child instanceof TextNode) {
                                                if (strongElementAppeared && (!((TextNode) child).text().equals("") || !((TextNode) child).text().equals(" "))) {
                                                    toAdd += ((TextNode) child).text() + " ";
                                                }
                                            } else {
                                                if (!child.toString().contains("<!--")) {
                                                    if (!((Element) child).text().trim().equals("") && !((Element) child).text().trim().equals(" ") && !child.toString().contains("<h2")) {
                                                        toAdd += ((Element) child).text() + " ";
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (!toAdd.equals("")) {
                                        descriptions2.add(toAdd);
                                    }
                                    if (!secOk) {
                                        if (headlines.size() - descriptions2.size() == 1) {
                                            headlines.remove(0);
                                        }
                                    }
                                }
                            }


                            if (headlines.size() > 0 && (descriptions.size() > 0 || descriptions2.size() > 0)) {
                                //remove empty headlines
                                for (int i = 0; i < headlines.size(); i++) {
                                    if (headlines.get(i).text().equals("")) {
                                        headlines.remove(i);
                                    }
                                }

                                //set the same capacity of headlines and descriptions
                                if (descriptions.size() > 0) { //new
                                    int removeValue = headlines.size() - descriptions.size();
                                    if (removeValue > 0) {
                                        for (int i = headlines.size() - 1; i >= descriptions.size(); i--) {
                                            headlines.remove(i);
                                        }
                                    }
                                }

                                if (descriptions2.size() > 0) { //new
                                    int removeValue = headlines.size() - descriptions2.size();
                                    if (removeValue > 0) {
                                        for (int i = headlines.size() - 1; i >= descriptions2.size(); i--) {
                                            headlines.remove(i);
                                        }
                                    }
                                }

                                //create JSON of medicine from search results

                                Map<String, Object> medicineInformation = new LinkedHashMap<>();
                                Map<String, Object> medicine = new LinkedHashMap<>();
                                medicineInformation.put("name", medicineFullName);
                                // if from second web medicine database
                                if (descriptions.size() > 0) {
                                    if (medicineFirstHeadline.size() > 0) {
                                        medicine.put("headline", medicineFirstHeadline.get("headline").toString().replaceAll("'", ""));
                                        medicine.put("content", descriptions.get(0).text().replaceAll("'", ""));
                                        medicineInformation.put("description1", medicine);
                                        descriptions.remove(0);
                                    }

                                    for (int i = 0; i < headlines.size(); i++) {
                                        medicine = new LinkedHashMap<>();
                                        medicine.put("headline", headlines.get(i).text().replaceAll("'", ""));
                                        medicine.put("content", descriptions.get(i).text().replaceAll("'", ""));
                                        if (medicineFirstHeadline.size() > 0) {
                                            medicineInformation.put("description" + (i + 2), medicine);
                                        } else {
                                            medicineInformation.put("description" + (i + 1), medicine);
                                        }
                                    }
                                }

                                if (descriptions2.size() > 0) {
//                                if (medicineFirstHeadline.size() > 0) {
//                                    medicine.put("headline", medicineFirstHeadline.get("headline"));
//                                    medicine.put("content", descriptions2.get(0));
//                                    medicineInformation.put("description1", medicine);
//                                    descriptions2.remove(0);
                                    //}

                                    for (int i = 0; i < headlines.size(); i++) {
                                        medicine = new LinkedHashMap<>();
                                        medicine.put("headline", headlines.get(i).text().replaceAll("'", ""));
                                        medicine.put("content", descriptions2.get(i).replaceAll("'", ""));
                                        medicineInformation.put("description" + (i + 1), medicine);
                                    }
                                }

                                this.mysql.insertMedicineData(medicineInformation, "");
                            } else {
                                if (doRecord == true && contentWas) {
                                    String op = "";
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println(e.getMessage());
                    String h = medicineFullName;
                    String hf = "";
                }
                descriptions2.clear();
                //}
            }
            linksSize--;
        }
        return null;
    }

    private String getShorterName(String medicineName) {

        String shorterName = "";
        try {
            String[] splitMedicineName = medicineName.split(" ");
            int length = 0;
            if (splitMedicineName.length > 0) {
                length = splitMedicineName.length;
                for (int i = 0; i < length - 1; i++) {
                    shorterName += splitMedicineName[i];
                    if ((i + 1) < length - 1) {
                        shorterName += " ";
                    }
                }
                return shorterName;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return medicineName;
    }

    private String getFirstLink(Elements subLinks) {
        String subLink = "";
        try {
            subLink = (String) subLinks.get(0).toString().subSequence(subLinks.get(0).toString().indexOf("\"") + 1, subLinks.get(0).toString().indexOf(">") - 1);
            if (subLink.contains(" ")) {
                subLink = subLink.split(" ")[0];
            }
            if (subLink.contains("\"")) {
                subLink = subLink.replaceAll("\"", "");
            }
            return subLink;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return subLink;
    }

    private static boolean isStringUpperCase(Node node) {

        try {
            String str = ((Element) node).text();
            //convert String to char array
            str = str.replaceAll("\\s", "");
            char[] charArray = str.toCharArray();

            if (str.trim().isEmpty()) {
                return false;
            }

            for (int i = 0; i < charArray.length; i++) {

                //if any character is not in upper case, return false
                if (!Character.isUpperCase(charArray[i]))
                    return false;
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean checkIfListsFromDatabaseContainMedicineName(ArrayList<String> list, String medicineName) {
        boolean ret = false;
        while (medicineName.contains(" ") && ret == false) {
            medicineName = getShorterName(medicineName);
            if (medicineName.contains(" ")) {
                for (String str : list) {
                    if (str.contains(medicineName)) {
                        ret = true;
                        break;
                    }
                }
            }
        }
//        if (medicineName.equals("oceanic")) {
//            String p = "";
//        }
        if (ret == false) {
            for (String str : list) {
                if (str.contains(" ")) {
                    //String o =str.split(" ")[0];
                    if (str.split(" ")[0].equals(medicineName)) {
                        ret = true;
                        break;
                    }
                } else {
                    if (str.contains(medicineName)) {
                        ret = true;
                        break;
                    }
                }
            }
        }
        return ret;
    }

}
