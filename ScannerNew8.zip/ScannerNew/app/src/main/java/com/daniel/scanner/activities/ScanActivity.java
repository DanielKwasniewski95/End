package com.daniel.scanner.activities;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;
import com.daniel.scanner.sqlite.MysqLite;
import com.daniel.scanner.utilities.OuterServer;
import com.google.zxing.Result;
import me.dm7.barcodescanner.zxing.ZXingScannerView;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ScanActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {

    private ZXingScannerView scannerView;
    private SQLiteDatabase sqLiteDatabase;
    private OuterServer outerServer;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        scannerView = new ZXingScannerView(this);   // Programmatically initialize the scanner view
        setContentView(scannerView);                // Set the scanner view as the content view
    }

    @Override
    public void onResume() {
        super.onResume();
        scannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
        scannerView.startCamera();          // Start camera on resume
    }

    @Override
    public void onPause() {
        super.onPause();
        scannerView.stopCamera();           // Stop camera on pause
    }

    @Override
    public void handleResult(Result rawResult) {
        // Do something with the result here
        // Log.v("tag", rawResult.getText()); // Prints scan results
        // Log.v("tag", rawResult.getBarcodeFormat().toString()); // Prints the scan format (qrcode, pdf417 etc.)

        //MainActivity.tvresult.setText(rawResult.getText());
        onBackPressed();

        this.outerServer = new OuterServer();

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("barcode", rawResult);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            JSONObject myResponse = outerServer.getMedicineInformation(jsonObject);
            System.out.println(myResponse);

            //sqLite

            this.sqLiteDatabase = this.openOrCreateDatabase("e-learning", MODE_PRIVATE, null);
            MysqLite.insertMedicineInfoData(this.sqLiteDatabase, myResponse);

            //readDataFrom sqLite
            List<String> list = new ArrayList<>();
            Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM medicine", null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String[] x = cursor.getColumnNames();
                    list.add(cursor.getString(0));
                    list.add(cursor.getString(1));
                    list.add(cursor.getString(2));
                    list.add(cursor.getString(3));
                    list.add(cursor.getString(4));
                }
            }
            //readDataFrom sqLite

            Toast.makeText(this, rawResult.getText(), Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Log.i("sql", e.toString());
            Toast.makeText(this, "Please check your internet connection.", Toast.LENGTH_LONG).show();
        }

        if (this.sqLiteDatabase.isOpen()) {
            this.sqLiteDatabase.close();
        }
    }
}

