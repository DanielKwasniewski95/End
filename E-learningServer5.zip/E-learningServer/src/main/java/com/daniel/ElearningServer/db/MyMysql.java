package com.daniel.ElearningServer.db;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class MyMysql {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private QueryHandler queryHandler;

    public MyMysql(QueryHandler queryHandler) {
        this.queryHandler = queryHandler;
    }

    public Map<String, Object> getMedicineInformation(String medicineName) {
        Map<String, Object> medicineInformation = new LinkedHashMap<>();
        List<Map<String, Object>> list = new ArrayList<>();
        try {
            String databaseTable = medicineName.substring(0, 1);
            boolean firstTime = true;
            while (medicineInformation.isEmpty()) {
                if (!firstTime) {
                    if (medicineName.contains(" ")) {
                        medicineName = getShorterName(medicineName);
                    } else {
                        break;
                    }
                }
                if (isInteger(databaseTable)) {
                    list = queryHandler.getData("SELECT * FROM medicineselse WHERE name LIKE '%" + medicineName + "%'");
                } else {
                    list = queryHandler.getData("SELECT * FROM medicines" + databaseTable + " WHERE name LIKE '%" + medicineName + "%'");
                }
                if (!list.isEmpty()) {
                    int howManyMedicinesFound = list.size();
                    if (howManyMedicinesFound > 1) {
                        for (Map map : list) {
                            medicineInformation.put("moreThenOne", "moreThenOne");
                            medicineInformation.put(map.get("name").toString(), "");
                        }
                    } else {
                        Map map = list.get(0);
                        medicineInformation.put("name", map.get("name").toString());
                        int headlinesAndDescriptionsCount = 1;
                        while (!map.get("headline" + headlinesAndDescriptionsCount).equals("") && map.get("headline" + headlinesAndDescriptionsCount) != null) {
                            Map<String, Object> medicineHeadlinesAndDescriptions = new LinkedHashMap<>();
                            medicineHeadlinesAndDescriptions.put("headline", map.get("headline" + headlinesAndDescriptionsCount));
                            medicineHeadlinesAndDescriptions.put("content", map.get("description" + headlinesAndDescriptionsCount));
                            medicineInformation.put("description" + headlinesAndDescriptionsCount, medicineHeadlinesAndDescriptions);
                            headlinesAndDescriptionsCount++;
                        }
                    }
                }
                firstTime = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return medicineInformation;
    }

    public void insertMedicineTreatmentData(Map<String, String> medicine) {
        String medicineName = medicine.get("name");
        int id = 0;
        if (medicineName != null) {
            id = getLastId("medicine_treatment");
            String data = checkIfRecordExists("medicine_treatment", medicineName);
            if (data.equals("brak danych") && id != -1) {
//                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//                Date date;
                try {
                    //date = simpleDateFormat.parse(medicine.get("startDate"));
                    StringBuilder sql = new StringBuilder();
                    sql.append("INSERT INTO medicine_treatment (id, name, dosage, tablets_taken" +
                            ", tablets_in_package, times_a_day, start_date) VALUES (" + id + ",'" + medicineName + "'" +
                            ", '" + medicine.get("dosage") + "', " + Integer.parseInt(medicine.get("tabletsTaken")) + ", " +
                            Integer.parseInt(medicine.get("tabletsInPackage")) + ", " +
                            Integer.parseInt(medicine.get("timesAday")) + ", '" + medicine.get("startDate") + "'");
                    sql.append(");");
                    queryHandler.execute(sql.toString());
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    }

    public void insertMedicineTreatmentDosingTimeData(Map<String, String> medicine) {
        String medicineName = medicine.get("name");
        int id = 0;
        if (medicineName != null) {
            id = getLastId("medicine_treatment_dosing_time");
            String data = checkIfRecordExists("medicine_treatment_dosing_time", medicineName);
            if (data.equals("brak danych") && id != -1) {
//                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//                Date date;
                try {
                    //date = simpleDateFormat.parse(medicine.get("startDate"));
                    StringBuilder sql = new StringBuilder();
                    sql.append("INSERT INTO medicine_treatment_dosing_time (id, name, dosing_time_1, dosing_time_2, dosing_time_3," +
                            "dosing_time_4, dosing_time_5, dosing_time_6, dosing_time_7, dosing_time_8, dosing_time_9, dosing_time_10) " +
                            "VALUES (" + id + ",'" + medicineName + "'");

                    for (int i = 1; i < medicine.size(); i++) {
                        sql.append(", '" + medicine.get("dosing_time_" + i) + "'");
                    }
                    //add null if medicine dosing_time fields are less then in the table
                    if (medicine.size() - 1 < 10) {
                        int emptyDosingTimes = 10 - (medicine.size() - 1); //id index 0
                        for (int i = 1; i <= emptyDosingTimes; i++) {
                            sql.append(",null");
                        }
                    }
                    sql.append(");");
                    queryHandler.execute(sql.toString());
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    }


    public void insertMedicineData(Map<String, Object> medi) {

        JSONObject medicine = new JSONObject(medi);
        int id = 0;

        String medicineName;
        medicineName = medicine.get("name").toString();
        if (medicineName != null) {
            id = getLastId("medicine");
            String data = checkIfRecordExists("medicine", medicineName);
            if (data.equals("brak danych") && id != -1) {
                StringBuilder sql = new StringBuilder();
                sql.append("INSERT INTO medicine (id, name,headline1, description1" +
                        ", headline2, description2, headline3, description3, headline4, description4" +
                        ", headline5, description5, headline6, description6, headline7, description7" +
                        ", headline8, description8, headline9, description9, headline10, description10" +
                        ", headline11, description11, headline12, description12, headline13, description13" +
                        ", headline14, description14, headline15, description15) VALUES (" + id + ",'" + medicineName + "'");

                int jsonLenght = medicine.length();
                int descriptionsAmount = medicine.length() - 2;
                JSONObject medicineDescription = null;

                for (int i = 1; i < jsonLenght; i++) {
                    medicineDescription = medicine.getJSONObject("description" + i);
                    if (medicineDescription != null) {
                        sql.append(",'" + medicineDescription.get("headline").toString() + "','" + medicineDescription.get("content").toString() + "'");
                    }
                }
                if (descriptionsAmount < 15) {
                    for (int i = 1; i < 15 - descriptionsAmount; i++) {
                        sql.append(",'',''");
                    }
                }
                sql.append(");");
                queryHandler.execute(sql.toString());
            }

        }
    }

    public String checkIfRecordExists(String table, String name) {

        String description = null;
        List<Map<String, Object>> medicine;
        try {
            medicine = this.queryHandler.getData("SELECT * FROM " + table + " WHERE name='" + name + "'");
        } catch (Exception e) {
            description = "brak danych";
            return description;
        }

        if (medicine.size() > 0) {
            description = medicine.get(0).get("name").toString();
        } else {
            description = "brak danych";
        }
        return description;
    }

    private int getLastId(String table) {

        int id = 1;
        List<Map<String, Object>> medicine;

        try {
            medicine = this.queryHandler.getData("SELECT * FROM " + table);
        } catch (Exception e) {
            id = -1;
            System.out.println(e);
            return id;
        }

        if (medicine.size() > 0) {
            for (Map map : medicine) {
                id++;
            }
        }
        return id;
    }

    private String calculateEndDateOfMedicine(String startDate, int tabletsInPackage, String dosage, int takenAtOnce, int timesADay) {

        Date endDate = new Date();
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(dateFormat.parse(startDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (dosage.equals("daily")) {
            int daysLeft = tabletsInPackage / timesADay;
            calendar.add(Calendar.DAY_OF_MONTH, daysLeft);
            endDate = calendar.getTime();
        }
        if (dosage.equals("twoTimesAweek")) {
            int daysLeft = tabletsInPackage / timesADay;
            calendar.add(Calendar.DAY_OF_MONTH, daysLeft * 2);
            endDate = calendar.getTime();
        }
        return endDate.toString();
    }

    private boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return false;
        } catch (NullPointerException e) {
            return false;
        }
        // only got here if we didn't return false
        return true;
    }

    private String getShorterName(String medicineName) {

        try {
            String[] splitMedicineName = medicineName.split(" ");

            if (splitMedicineName.length > 0) {
                if (splitMedicineName.length == 3) {
                    return splitMedicineName[0] + " " + splitMedicineName[1];
                } else if (splitMedicineName.length == 2) {
                    return splitMedicineName[0];
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}