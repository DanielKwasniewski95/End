package com.daniel.scanner.sqlite;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONException;
import org.json.JSONObject;

public class MysqLite {

    public static void insertMedicineFortreatment(SQLiteDatabase sqLiteDatabase){

    }

    public static void insertMedicineInfoData(SQLiteDatabase sqLiteDatabase, JSONObject medicine) {

        String medicineName = null;
        try {
            medicineName = medicine.get("name").toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (medicineName != null) {
            String data = checkIfMedicineInfoExists(sqLiteDatabase, medicineName);
            if (data.equals("brak danych")) {
                StringBuilder sql = new StringBuilder();
                sql.append("INSERT INTO medicine (id, name,headline1, description1" +
                        ", headline2, description2, headline3, description3, headline4, description4" +
                        ", headline5, description5, headline6, description6, headline7, description7" +
                        ", headline8, description8, headline9, description9, headline10, description10" +
                        ", headline11, description11, headline12, description12, headline13, description13" +
                        ", headline14, description14, headline15, description15) VALUES (1,'" + medicineName + "'");

                int jsonLenght = medicine.length();
                int descriptionsAmount = medicine.length() - 2;
                JSONObject medicineDescription = null;

                for (int i = 1; i < jsonLenght; i++) {
                    try {
                        medicineDescription = medicine.getJSONObject("description" + i);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if (medicineDescription != null) {
                        try {
                            sql.append(",'" + medicineDescription.get("headline").toString() + "','" + medicineDescription.get("content").toString() + "'");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (descriptionsAmount < 15) {
                    for (int i = 1; i < 15 - descriptionsAmount; i++) {
                        sql.append(",'',''");
                    }
                }
                sql.append(");");
                sqLiteDatabase.execSQL(sql.toString());
            }

        }
    }

    public static String checkIfMedicineInfoExists(SQLiteDatabase sqLiteDatabase, String name) {

        String description = null;
        Cursor data = sqLiteDatabase.rawQuery("SELECT * FROM medicine WHERE name='" + name + "'", null);

        if (data != null) {
            data.moveToFirst();
            description = data.getString(data.getColumnIndex("name"));
        } else {
            description = "brak danych";
        }
        return description;
    }

}
