package com.daniel.scanner.web;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;

public class WebContent {

    private SslFactory sslFactory;

    public static final String GOOGLE_SEARCH_URL = "https://www.google.com/search";
    public static final String OPEN_PHARMACY = "https://openpharmacy.pl/?s=";
    public static final String MEDICINES_WEB_DATABASE = "https://bazalekow.mp.pl/leki/szukaj.html?item_name=";
    public static final String MEDICINES_WEB_DATABASE_2 = "https://www.lekinfo24.pl/wyniki-wyszukiwania?qh=";

    public Document search(String type, String urlContent) {
        String searchURL = GOOGLE_SEARCH_URL + "?q=" + urlContent + "&num=1";

        if (type.equals("nameSearch")) {
            searchURL = GOOGLE_SEARCH_URL + "?q=" + urlContent + "&num=1";
        } else if (type.equals("nameSearch2")) {
            searchURL = OPEN_PHARMACY + urlContent + "&submit=Szukaj...";
        } else if (type.equals("sublink")) {
            searchURL = MEDICINES_WEB_DATABASE + urlContent;
        }   else if (type.equals("sublink2")) {
            searchURL = MEDICINES_WEB_DATABASE_2 + urlContent;
        } else {
            searchURL = urlContent;
        }

        Document doc = null;

        try {
            sslFactory = new SslFactory();
            if (!searchURL.contains("http")) {
                doc = Jsoup.connect("https://www.lekinfo24.pl" + searchURL).sslSocketFactory(sslFactory.socketFactory()).get();
            } else {
                doc = Jsoup.connect(searchURL).sslSocketFactory(sslFactory.socketFactory()).get();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return doc;
    }

}
