package com.daniel.scanner.utilities;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;

public class OuterServer {

    private URL url;

    public JSONObject getMedicineInformation(JSONObject jsonObject) {

        JSONObject myResponse = null;
        try {
            URLConnection conn = getConnection("barcode");

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            //theJSONYouWantToSend should be the JSONObject as String
            wr.write(jsonObject.toString());  //<--- sending data.

            wr.flush();

            StringBuffer response = new StringBuffer();
            String line = null;
            BufferedReader serverAnswer = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            while ((inputLine = serverAnswer.readLine()) != null) {
                response.append(inputLine);
            }
            serverAnswer.close();
            myResponse = new JSONObject(response.toString());
            wr.close();

        } catch (Exception e) {
            System.out.println(e);
        }

        return myResponse;
    }

    public void sendMedicineTreatmentData(JSONObject jsonObject) {
        try {
            URLConnection conn = getConnection("insert_treatment");

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(jsonObject.toString());  //<--- sending data.

            wr.flush();
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = rd.readLine()) != null) {
                System.out.println(line);
            }
            wr.close();
            rd.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private URLConnection getConnection(String endpoint) {
        try {
            this.url = new URL("http://192.168.0.184:8090/" + endpoint);
            //URL url = new URL("http://192.168.0.105:8090/barcode");
            //Open the connection here, and remember to close it when job its done.
            URLConnection conn = url.openConnection();
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);

            return conn;
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

}
