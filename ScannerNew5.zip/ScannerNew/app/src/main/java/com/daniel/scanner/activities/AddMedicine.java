package com.daniel.scanner.activities;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import com.daniel.scanner.R;

public class AddMedicine extends AppCompatActivity {

    private Spinner dosageSpinner;
    private EditText medicineNameEditText;
    private static final String[] dosageList = {"daily", "weekly", "monthly"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medicine);

        this.dosageSpinner = findViewById(R.id.dosageSpinner);
        this.medicineNameEditText = findViewById(R.id.medicineNameEditText);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(AddMedicine.this,
                android.R.layout.simple_spinner_item, this.dosageList);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.dosageSpinner.setAdapter(adapter);
        //this.dosageSpinner.setOnItemSelectedListener(this);

        this.medicineNameEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });
    }

    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
