package com.daniel.ElearningServer.db;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class myMysql {

    private QueryHandler queryHandler;

    public myMysql(QueryHandler queryHandler) {
        this.queryHandler = queryHandler;
    }

    public void insertData(Map<String, Object> medi) {

        JSONObject medicine = new JSONObject(medi);

        String medicineName = null;
        medicineName = medicine.get("name").toString();
        if (medicineName != null) {
            //String data = getData(medicineName);
            String data = "brak danych";
            if (data.equals("brak danych")) {
                StringBuilder sql = new StringBuilder();
                sql.append("INSERT INTO medicine (id, name,headline1, description1" +
                        ", headline2, description2, headline3, description3, headline4, description4" +
                        ", headline5, description5, headline6, description6, headline7, description7" +
                        ", headline8, description8, headline9, description9, headline10, description10" +
                        ", headline11, description11, headline12, description12, headline13, description13" +
                        ", headline14, description14, headline15, description15) VALUES (1,'" + medicineName + "'");

                int jsonLenght = medicine.length();
                int descriptionsAmount = medicine.length() - 2;
                JSONObject medicineDescription = null;

                for (int i = 1; i < jsonLenght; i++) {
                    medicineDescription = medicine.getJSONObject("description"+1);
                    if (medicineDescription != null) {
                        sql.append(",'" + medicineDescription.get("headline").toString() + "','" + medicineDescription.get("content").toString() + "'");
                    }
                }
                if (descriptionsAmount < 15) {
                    for (int i = 1; i < 15 - descriptionsAmount; i++) {
                        sql.append(",'',''");
                    }
                }
                sql.append(");");
                queryHandler.execute(sql.toString());
            }

        }
    }

    public static String getData(String name) {

       /* String description = null;
        Cursor data = sqLiteDatabase.rawQuery("SELECT * FROM medicine WHERE name='" + name + "'", null);

        if (data != null) {
            data.moveToFirst();
            description = data.getString(data.getColumnIndex("name"));
        } else {
            description = "brak danych";
        }
        return description;
    }*/
return null;
    }
}
