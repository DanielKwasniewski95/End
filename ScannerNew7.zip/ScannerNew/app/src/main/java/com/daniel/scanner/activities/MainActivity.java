package com.daniel.scanner.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.StrictMode;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.daniel.scanner.R;

public class MainActivity extends AppCompatActivity {

    //public static TextView tvresult;
    public static TextView propertiesView;
    private static ListView listView;
    private Button btn;
    private Button btn2;
    private Button btn3;
    private SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //allowing connect to server
        if (android.os.Build.VERSION.SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        //end here

        //tvresult = findViewById(R.id.tvresult );
        propertiesView = findViewById(R.id.propertiesList);
        listView = findViewById(R.id.listView);

        btn = findViewById(R.id.btn);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);

        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.CAMERA}, 1);
        }
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.INTERNET)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.INTERNET}, 2);
        }

        //sqLite
        try {
            sqLiteDatabase = this.openOrCreateDatabase("e-learning", MODE_PRIVATE, null);

            //sqLiteDatabase.execSQL("DROP TABLE medicine");
            sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS medicine (id INT, name VARCHAR, headline1 TEXT, description1 TEXT" +
                    ", headline2 TEXT, description2 TEXT, headline3 TEXT, description3 TEXT, headline4 TEXT, description4 TEXT" +
                    ", headline5 TEXT, description5 TEXT, headline6 TEXT, description6 TEXT, headline7 TEXT, description7 TEXT" +
                    ", headline8 TEXT, description8 TEXT, headline9 TEXT, description9 TEXT, headline10 TEXT, description10 TEXT" +
                    ", headline11 TEXT, description11 TEXT, headline12 TEXT, description12 TEXT, headline13 TEXT, description13 TEXT" +
                    ", headline14 TEXT, description14 TEXT, headline15 TEXT, description15 TEXT)");

            sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS medicine_treatment (id INT, name VARCHAR, dosage INT, tablets_taken INT" +
                    ", tablets_in_package INT, start_date DATE)");

        } catch (Exception e) {
            Log.i("sql", e.toString());
        }finally {
            sqLiteDatabase.close();
        }
        //sqLite

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ScanActivity.class);
                startActivity(intent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TextRecognizeActivity.class);
                startActivity(intent);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddMedicineActivity.class);
                startActivity(intent);
            }
        });

    }

    static ListView getListView(){
        return listView;
    }

    static void setListView(ArrayAdapter arrayAdapter){
        listView.setAdapter(arrayAdapter);
    }
}
