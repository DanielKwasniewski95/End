package com.daniel.ElearningServer.db;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class MyMysql {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private QueryHandler queryHandler;

    public MyMysql(QueryHandler queryHandler) {
        this.queryHandler = queryHandler;
    }

    public void insertMedicineTreatmentData(Map<String, String> medicine) {
        String medicineName = medicine.get("name");
        int id = 0;
        if (medicineName != null) {
            id = getLastId("medicine_treatment");
            String data = checkIfRecordExists("medicine_treatment", medicineName);
            if (data.equals("brak danych") && id != -1) {
//                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//                Date date;
                try {
                    //date = simpleDateFormat.parse(medicine.get("startDate"));
                    StringBuilder sql = new StringBuilder();
                    sql.append("INSERT INTO medicine_treatment (id, name, dosage, tablets_taken" +
                            ", tablets_in_package, times_a_day, start_date) VALUES (" + id + ",'" + medicineName + "'" +
                            ", '" + medicine.get("dosage") + "', " + Integer.parseInt(medicine.get("tabletsTaken")) + ", " +
                            Integer.parseInt(medicine.get("tabletsInPackage")) + ", " +
                            Integer.parseInt(medicine.get("timesAday")) + ", '" + medicine.get("startDate") + "'");
                    sql.append(");");
                    queryHandler.execute(sql.toString());
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    }

    public void insertMedicineTreatmentDosingTimeData(Map<String, String> medicine) {
        String medicineName = medicine.get("name");
        int id = 0;
        if (medicineName != null) {
            id = getLastId("medicine_treatment_dosing_time");
            String data = checkIfRecordExists("medicine_treatment_dosing_time", medicineName);
            if (data.equals("brak danych") && id != -1) {
//                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//                Date date;
                try {
                    //date = simpleDateFormat.parse(medicine.get("startDate"));
                    StringBuilder sql = new StringBuilder();
                    sql.append("INSERT INTO medicine_treatment_dosing_time (id, name, dosing_time_1, dosing_time_2, dosing_time_3," +
                            "dosing_time_4, dosing_time_5, dosing_time_6, dosing_time_7, dosing_time_8, dosing_time_9, dosing_time_10) " +
                            "VALUES (" + id + ",'" + medicineName + "'");

                    for (int i = 1; i < medicine.size(); i++) {
                        sql.append(", '" + medicine.get("dosing_time_" + i) + "'");
                    }
                    //add null if medicine dosing_time fields are less then in the table
                    if (medicine.size() - 1 < 10) {
                        int emptyDosingTimes = 10 - (medicine.size() - 1); //id index 0
                        for (int i = 1; i <= emptyDosingTimes; i++) {
                            sql.append(",null");
                        }
                    }
                    sql.append(");");
                    queryHandler.execute(sql.toString());
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    }


    public void insertMedicineData(Map<String, Object> medi, String table) {

        JSONObject medicine = new JSONObject(medi);
        int id = 0;

        String medicineName;
        medicineName = medicine.get("name").toString();
        if (medicineName != null) {
            id = getLastId(table);
            String data = checkIfRecordExists(table, medicineName);
            if (data.equals("brak danych") && id != -1) {
                StringBuilder sql = new StringBuilder();
//                sql.append("INSERT INTO medicine3 (id, name,headline1, description1" +
//                        ", headline2, description2, headline3, description3, headline4, description4" +
//                        ", headline5, description5, headline6, description6, headline7, description7" +
//                        ", headline8, description8, headline9, description9, headline10, description10" +
//                        ", headline11, description11, headline12, description12, headline13, description13" +
//                        ", headline14, description14, headline15, description15) VALUES (" + id + ",'" + medicineName + "'");
                sql.append("INSERT INTO " + table + " (id, name,headline1, description1" +
                        ", headline2, description2, headline3, description3, headline4, description4" +
                        ", headline5, description5, headline6, description6, headline7, description7" +
                        ", headline8, description8, headline9, description9, headline10, description10" +
                        ", headline11, description11, headline12, description12, headline13, description13" +
                        ", headline14, description14, headline15, description15, headline16, description16," +
                        "headline17, description17, headline18, description18, headline19, description19," +
                        "headline20, description20, headline21, description21, headline22, description22," +
                        "headline23, description23, headline24, description24, headline25, description25," +
                        "headline26, description26, headline27, description27, headline28, description28," +
                        "headline29, description29, headline30, description30) VALUES (" + id + ",'" + medicineName + "'");

                int jsonLenght = medicine.length();
                int descriptionsAmount = medicine.length() - 2;
                JSONObject medicineDescription = null;

                for (int i = 1; i < jsonLenght; i++) {
                    medicineDescription = medicine.getJSONObject("description" + i);
                    if (medicineDescription != null) {
                        sql.append(",'" + medicineDescription.get("headline").toString() + "','" + medicineDescription.get("content").toString() + "'");
                    }
                }
                if (descriptionsAmount < 30) {
                    for (int i = 1; i < 30 - descriptionsAmount; i++) {
                        sql.append(",'',''");
                    }
                }
                sql.append(");");
                try {
                    queryHandler.execute(sql.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println(e.getMessage());
                    String x = "";
                }
            }

        }
    }

    public String checkIfRecordExists(String table, String name) {

        String description = null;
        List<Map<String, Object>> medicine;
        try {
            medicine = this.queryHandler.getData("SELECT * FROM " + table + " WHERE name='" + name + "'");
        } catch (Exception e) {
            description = "brak danych";
            return description;
        }

        if (medicine.size() > 0) {
            description = medicine.get(0).get("name").toString();
        } else {
            description = "brak danych";
        }
        return description;
    }

    public List<Map<String, Object>> getDataWithoutDescription() {

        String description = null;
        List<Map<String, Object>> medicine = null;
        try {
            medicine = this.queryHandler.getData("SELECT * FROM medicine WHERE headline1=''");
        } catch (Exception e) {
       e.printStackTrace();
        }

        return medicine;
    }

    public List<Map<String, Object>> getDataWithDescription(String table) {

        String description = null;
        List<Map<String, Object>> medicine = null;
        try {
            medicine = this.queryHandler.getData("SELECT * FROM " + table + ";");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return medicine;
    }


    private int getLastId(String table) {

        int id = 1;
        List<Map<String, Object>> medicine;

        try {
            medicine = this.queryHandler.getData("SELECT * FROM " + table);
        } catch (Exception e) {
            id = -1;
            System.out.println(e);
            return id;
        }

        if (medicine.size() > 0) {
            for (Map map : medicine) {
                id++;
            }
        }
        return id;
    }

    private String calculateEndDateOfMedicine(String startDate, int tabletsInPackage, String dosage, int takenAtOnce, int timesADay) {

        Date endDate = new Date();
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(dateFormat.parse(startDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (dosage.equals("daily")) {
            int daysLeft = tabletsInPackage / timesADay;
            calendar.add(Calendar.DAY_OF_MONTH, daysLeft);
            endDate = calendar.getTime();
        }
        if (dosage.equals("twoTimesAweek")) {
            int daysLeft = tabletsInPackage / timesADay;
            calendar.add(Calendar.DAY_OF_MONTH, daysLeft * 2);
            endDate = calendar.getTime();
        }
        return endDate.toString();
    }
}