package com.daniel.scanner.activities;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;
import com.google.zxing.Result;
import me.dm7.barcodescanner.zxing.ZXingScannerView;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;

public class ScanActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {

    private ZXingScannerView scannerView;
    private SQLiteDatabase sqLiteDatabase;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        scannerView = new ZXingScannerView(this);   // Programmatically initialize the scanner view
        setContentView(scannerView);                // Set the scanner view as the content view
    }

    @Override
    public void onResume() {
        super.onResume();
        scannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
        scannerView.startCamera();          // Start camera on resume
    }

    @Override
    public void onPause() {
        super.onPause();
        scannerView.stopCamera();           // Stop camera on pause
    }

    @Override
    public void handleResult(Result rawResult) {
        // Do something with the result here
        // Log.v("tag", rawResult.getText()); // Prints scan results
        // Log.v("tag", rawResult.getBarcodeFormat().toString()); // Prints the scan format (qrcode, pdf417 etc.)

        //MainActivity.tvresult.setText(rawResult.getText());
        onBackPressed();

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("barcode", rawResult);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
              URL url = new URL("http://192.168.0.184:8090/barcode");
            //URL url = new URL("http://192.168.0.105:8090/barcode");
            //Open the connection here, and remember to close it when job its done.
            URLConnection conn = url.openConnection();
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);

            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            //theJSONYouWantToSend should be the JSONObject as String
            wr.write(jsonObject.toString());  //<--- sending data.

            wr.flush();

            StringBuffer response = new StringBuffer();
            String line = null;
            BufferedReader serverAnswer = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            /*String line = serverAnswer.readLine();
            List<String> result = new ArrayList<>();
            while (line != null) {

                result.add(line); //<--If any response from server
                line = serverAnswer.readLine();
                //use it as you need, if server send something back you will get it here.
            }*/
            String inputLine;
            while ((inputLine = serverAnswer.readLine()) != null) {
                response.append(inputLine);
            }
            serverAnswer.close();
            JSONObject myResponse = new JSONObject(response.toString());

            //sqLite
            try {
                sqLiteDatabase = this.openOrCreateDatabase("e-learning", MODE_PRIVATE, null);

            } catch (Exception e) {
                Log.i("sql", e.toString());
            }

            //String data = result.toString();
          /*  String[] columnNames;
            Cursor c = sqLiteDatabase.rawQuery("SELECT * FROM medicine", null);
            String column = c.getColumnName(1);
            try {
                columnNames = c.getColumnNames();
            } finally {
                c.close();
                sqLiteDatabase.close();
            }*/
            //Log.i("columns", columnNames);
            //JSONObject jo = myResponse.getJSONObject("description1");
            //MysqLite.insertData(this.sqLiteDatabase,myResponse);
            //String data2 = MysqLite.getData(this.sqLiteDatabase,"Rutinoscorbin");
            //sqLite

            Toast.makeText(this, rawResult.getText(), Toast.LENGTH_LONG).show();
            //MainActivity.tvresult.setText(getInformationAboutMedicine(getSubLinks(getName(rawResult.toString()))));

            //List<String> medicinePropertiesList = medicine.getInformationAboutMedicine(rawResult.toString());

            //wyswietl opis leku
           /* ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_list_item_1,
                    result );

            MainActivity.setListView(arrayAdapter);*/
            //wyswietl opis leku
            //wr.close();
        }catch (Exception e){
            Log.i("exc", e.toString());
            Toast.makeText(this, "Please check your internet connection.", Toast.LENGTH_LONG).show();
        }

        // If you would like to resume scanning, call this method below:
        //scannerView.resumeCameraPreview(this);
    }
}

