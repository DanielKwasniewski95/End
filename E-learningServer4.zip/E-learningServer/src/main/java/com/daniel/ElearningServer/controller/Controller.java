package com.daniel.ElearningServer.controller;

import com.daniel.ElearningServer.db.MyMysql;
import com.daniel.ElearningServer.service.MedicineInfo;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class Controller {

    private MedicineInfo medicineInfo;
    private MyMysql myMysql;

    public Controller(MedicineInfo medicineInfo, MyMysql myMysql) {
        this.medicineInfo = medicineInfo;
        this.myMysql = myMysql;

    }

    @RequestMapping(value = "/barcode", method = RequestMethod.POST)
    public Map<String, Object> getMedicineInformation(@RequestBody Map<String, String> map) {

        String barcode = map.get("barcode");

        return medicineInfo.getInformationAboutMedicine(barcode);

    }

    @RequestMapping(value = "/insert_treatment", method = RequestMethod.POST)
    public void insertTreatmentMedicine(@RequestBody Map<String, String> map) {

        this.myMysql.insertMedicineTreatmentData(map);
    }
}
