package com.daniel.scanner.activities;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.icu.util.Calendar;
import android.inputmethodservice.Keyboard;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import com.daniel.scanner.R;
import com.daniel.scanner.sqlite.MysqLite;
import com.daniel.scanner.utilities.OuterServer;
import com.daniel.scanner.utilities.UserInput;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class AddMedicineActivity extends AppCompatActivity {

    private Spinner dosageSpinner;
    private EditText medicineNameEditText;
    private EditText numberOfTabletsTakenAtOnce;
    private EditText numberOfTabletsInPackage;
    private EditText timesAdayEditText;
    private TextView startDateTextView;
    private Button dateButton;
    private Button saveButton;
    private static final String[] dosageList = {"daily", "weekly", "monthly"};

    private SQLiteDatabase sqLiteDatabase;
    private OuterServer outerServer;

    private DatePickerDialog.OnDateSetListener onDateSetListener;
    private UserInput userInput;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medicine);

        RelativeLayout layout = findViewById(R.id.addMedicineLayout);
        layout.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View view, MotionEvent ev)
            {
                hideKeyboard(view);
                return false;
            }
        });

        this.dosageSpinner = findViewById(R.id.dosageSpinner);
        this.medicineNameEditText = findViewById(R.id.medicineNameEditText);
        this.numberOfTabletsTakenAtOnce = findViewById(R.id.numberOfTabletsTaken);
        this.numberOfTabletsInPackage = findViewById(R.id.numberOfTabletsInPackage);
        this.timesAdayEditText = findViewById(R.id.timesAdayEditText);
        this.startDateTextView = findViewById(R.id.startDateTextView);
        this.dateButton = findViewById(R.id.dateButton);
        this.saveButton = findViewById(R.id.saveButton);
        //datePicker

        this.dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        AddMedicineActivity.this,
                        R.style.PickerDialogTheme,
                        onDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                dialog.show();
            }
        });

        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                //Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                String dayString = String.valueOf(day);
                String monthString = String.valueOf(month);
                if (dayString.length() == 1) {
                    dayString = "0" + dayString;
                }
                if (monthString.length() == 1) {
                    monthString = "0" + monthString;
                }
                String date = year + "-" + monthString + "-" + dayString;
                startDateTextView.setText(date);
            }
        };
        //datePicker

        /*SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        this.startDateEditText = new Date();
        try{
            this.startDateEditText = dateFormat.parse(findViewById(R.id.startDateEditText).toString());
        } catch (Exception e){
            System.out.println(e);
        }*/

        //fillDosageSpinner
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(AddMedicineActivity.this,
                android.R.layout.simple_spinner_item, this.dosageList);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.dosageSpinner.setAdapter(adapter);
        //fillDosageSpinner

        //hide keyboard for all editText
//        this.medicineNameEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//            @Override
//            public void onFocusChange(View v, boolean hasFocus) {
//                if (!hasFocus) {
//                    hideKeyboard(v);
//                }
//            }
//        });
        //hide keyboard for all editText

//        try {
//            sqLiteDatabase = this.openOrCreateDatabase("e-learning", MODE_PRIVATE, null);
//        } catch (Exception e) {
//            Log.i("sql", e.toString());
//        }

        this.userInput = new UserInput();
        this.saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinkedHashMap<String, String> medicineTreatmentInfo = new LinkedHashMap<>();
                medicineTreatmentInfo.put("name", medicineNameEditText.getText().toString());
                medicineTreatmentInfo.put("dosage", dosageSpinner.getSelectedItem().toString());
                medicineTreatmentInfo.put("tabletsTaken", numberOfTabletsTakenAtOnce.getText().toString());
                medicineTreatmentInfo.put("tabletsInPackage", numberOfTabletsInPackage.getText().toString());
                medicineTreatmentInfo.put("timesAday", timesAdayEditText.getText().toString());
                medicineTreatmentInfo.put("startDate", startDateTextView.getText().toString());
                //MysqLite.insertMedicineForTreatment(sqLiteDatabase, medicineTreatmentInfo);

                if (userInput.doesUserFilledAllInputs(medicineTreatmentInfo)) {
//                    JSONObject jsonObject = new JSONObject(medicineTreatmentInfo);
//                    outerServer = new OuterServer();
//                    outerServer.sendMedicineTreatmentData(jsonObject);

                    //add data to sqlite
//                    sqLiteDatabase = getApplicationContext().openOrCreateDatabase("e-learning", MODE_PRIVATE, null);
//                    MysqLite.insertMedicineForTreatment(sqLiteDatabase, medicineTreatmentInfo);

                    // Map<String, String> list = MysqLite.readData(sqLiteDatabase, "SELECT * FROM medicine_treatment");
//                    if (sqLiteDatabase.isOpen()) {
//                        sqLiteDatabase.close();
//                    }
//                Intent intent = new Intent(AddMedicineActivity.this, MainActivity.class);
//                startActivity(intent);
                    Intent intent = new Intent(AddMedicineActivity.this, AddMedicineActivity_dosingTime.class);
                    intent.putExtra("medicineTreatmentInfoMap", medicineTreatmentInfo);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Proszę wypełnić wszystkie pola", Toast.LENGTH_LONG).show();
                }
            }
        });

//        if (sqLiteDatabase.isOpen()) {
//            sqLiteDatabase.close();
//        }
    }

    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }



}
