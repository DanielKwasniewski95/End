package com.daniel.ElearningServer.controller;

import com.daniel.ElearningServer.db.MyMysql;
import com.daniel.ElearningServer.service.MedicineInfo;
import com.daniel.ElearningServer.service.SortDb;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RestController
public class Controller {

    private MedicineInfo medicineInfo;
    private MyMysql myMysql;
    private SortDb sortDb;

    public Controller(MedicineInfo medicineInfo, MyMysql myMysql, SortDb sortDb) {
        this.medicineInfo = medicineInfo;
        this.myMysql = myMysql;
        this.sortDb = sortDb;
    }

    @RequestMapping(value = "/sort", method = RequestMethod.GET)
    public String doSort() {
        this.sortDb.createMapForInsert();
        return "started";
    }

    @RequestMapping(value = "/barcode", method = RequestMethod.GET)
    public String getMedicineInformation() {
        createDB();
        return "started";

    }

    @RequestMapping(value = "/insert_treatment", method = RequestMethod.POST)
    public void insertTreatmentMedicine(@RequestBody Map<String, String> map) {

        this.myMysql.insertMedicineTreatmentData(map);
    }

    @RequestMapping(value = "/insert_treatment_dosing_time", method = RequestMethod.POST)
    public void insertTreatmentMedicineDosingTime(@RequestBody Map<String, String> map) {

        System.out.println(map);
        this.myMysql.insertMedicineTreatmentDosingTimeData(map);
    }

    private void createDB() {
        Thread thread = new Thread("New Thread") {
            public void run(){
                medicineInfo.getInformationAboutMedicine("");
                System.out.println("end");
            }
        };


        thread.start();

    }
}
