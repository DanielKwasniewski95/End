package com.daniel.scanner.activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;
import com.daniel.scanner.medicine.MedicineInfo;
import com.daniel.scanner.sqlite.MysqLite;
import com.daniel.scanner.utilities.OuterServer;
import com.google.zxing.Result;
import me.dm7.barcodescanner.zxing.ZXingScannerView;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ScanActivity_NoServer extends AppCompatActivity implements ZXingScannerView.ResultHandler {

    private ZXingScannerView scannerView;
    private SQLiteDatabase sqLiteDatabase;
    private OuterServer outerServer;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        scannerView = new ZXingScannerView(this);   // Programmatically initialize the scanner view
        setContentView(scannerView);                // Set the scanner view as the content view
    }

    @Override
    public void onResume() {
        super.onResume();
        scannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
        scannerView.startCamera();          // Start camera on resume
    }

    @Override
    public void onPause() {
        super.onPause();
        scannerView.stopCamera();           // Stop camera on pause
    }

    @Override
    public void handleResult(Result rawResult) {
        // Do something with the result here
        // Log.v("tag", rawResult.getText()); // Prints scan results
        // Log.v("tag", rawResult.getBarcodeFormat().toString()); // Prints the scan format (qrcode, pdf417 etc.)

        //MainActivity.tvresult.setText(rawResult.getText());
        onBackPressed();

        MedicineInfo medicineInfo = new MedicineInfo();
        LinkedHashMap<String, Object> foundMedicineInformation = new LinkedHashMap<>(medicineInfo.getInformationAboutMedicine(rawResult.toString()));

        Intent intent = new Intent(ScanActivity_NoServer.this, ScanResult.class);
        intent.putExtra("foundMedicineInformation", foundMedicineInformation);
        startActivity(intent);
    }
}

