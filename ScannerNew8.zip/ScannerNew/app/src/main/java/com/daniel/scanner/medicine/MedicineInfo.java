package com.daniel.scanner.medicine;

import com.daniel.scanner.web.WebContent;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.LinkedHashMap;
import java.util.Map;

public class MedicineInfo {

    private Document doc = null;
    private WebContent webContent;

    public MedicineInfo() {
        this.webContent = new WebContent();
    }

    private String getName(String searchType, String searchTerm) {

        String medicineName = "";

        this.doc = webContent.search(searchType, searchTerm);

        Elements results = doc.select("h3.LC20lb");

        try {
            if (results.size() == 0) {
                //searchAgain
                results = doc.select("h2.post-title > a");
            }
            if (results.size() > 0) {
                String[] result = results.get(0).text().split(" ");
                if (!result[0].equals("-") && !result[1].equals("-") && !result[2].equals("-"))
                    medicineName = result[0] + " " + result[1] + " " + result[2];
                else if (!result[0].equals("-") && !result[1].equals("-") && result[2].equals("-")) {
                    medicineName = result[0] + " " + result[1];
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return medicineName;
    }

    private String getSubLinks(String medicineName, int database) {

        String subLink = "";

        if (database == 1) {
            this.doc = webContent.search("sublink", medicineName);

            Elements subLinks = doc.select("ul.item-found > li > a");

            if (subLinks.size() > 0) {
                subLink = getFirstLink(subLinks);
            }
        } else {
            this.doc = webContent.search("sublink2", medicineName);

            Elements subLinks = doc.select("ul.lista-handlowe > li > a");

            if (subLinks.size() > 0) {
                subLink = getFirstLink(subLinks);
            }
        }
        return subLink;
    }

    public Map<String, Object> getInformationAboutMedicine(String scanResult) {

        String medicineFullName = "";
        int medicineWebDatabase = 1;
        Elements headlines = null;
        Elements descriptions = null;
        Map<String, Object> medicineFirstHeadline = new LinkedHashMap<>();

        String medicineName = getName("nameSearch", scanResult);
        if (medicineName == null || medicineName.equals("")) {
            medicineName = getName("nameSearch2", scanResult);
        } else {
            medicineFullName = medicineName;
        }
        String url = getSubLinks(medicineName, medicineWebDatabase);

        if (url.isEmpty()) {
            medicineName = getShorterName(medicineName);
            url = getSubLinks(medicineName, medicineWebDatabase);
            medicineFullName = medicineName;
        }

        if (url.isEmpty()) {
            medicineName = getShorterName(medicineName);
            url = getSubLinks(medicineName, medicineWebDatabase);
            medicineFullName = medicineName;
        }

        if (!url.isEmpty()) {
            this.doc = webContent.search("medicineInformation", url);

            headlines = doc.select("h2");
            descriptions = doc.select("div.item-content");
        }

        if (headlines == null || descriptions == null || headlines.size() == 0 || descriptions.size() == 0) {
            medicineWebDatabase = 2;
            medicineName = getName("nameSearch", scanResult);
            if (medicineName == null || medicineName.equals("")) {
                medicineName = getName("nameSearch2", scanResult);
            }
            url = getSubLinks(medicineName, medicineWebDatabase);

            if (url.isEmpty()) {
                medicineName = getShorterName(medicineName);
                url = getSubLinks(medicineName, medicineWebDatabase);
            }

            if (url.isEmpty()) {
                medicineName = getShorterName(medicineName);
                url = getSubLinks(medicineName, medicineWebDatabase);
            }

            if (!url.isEmpty()) {
                this.doc = webContent.search("medicineInformation", url);

                headlines = doc.select("div.opis-leku-pacjent-auto > div.s > h2");

                medicineFirstHeadline.put("headline", headlines.get(0).text());

                headlines = doc.select("div.opis-leku-pacjent-auto > div.s > h4");
                descriptions = doc.select("div.opis-leku-pacjent-auto > div.s > p");
            }
        }
        //remove empty headlines
        for (int i = 0; i < headlines.size(); i++) {
            if (headlines.get(i).text().equals("")) {
                headlines.remove(i);
            }
        }

        //set the same capacity of headlines and descriptions
        int removeValue = headlines.size() - descriptions.size();
        if (removeValue > 0) {
            for (int i = headlines.size() - 1; i >= descriptions.size(); i--) {
                headlines.remove(i);
            }
        }

        //create JSON of medicine from search results
        Map<String, Object> medicineInformation = new LinkedHashMap<>();
        Map<String, Object> medicine = new LinkedHashMap<>();
        medicineInformation.put("name", medicineFullName);
        // if from second web medicine database
        if (medicineFirstHeadline.size() > 0) {
            medicine.put("headline", medicineFirstHeadline.get("headline"));
            medicine.put("content", descriptions.get(0).text());
            medicineInformation.put("description1", medicine);
            descriptions.remove(0);
        }

        for (int i = 0; i < headlines.size(); i++) {
            medicine = new LinkedHashMap<>();
            medicine.put("headline", headlines.get(i).text());
            medicine.put("content", descriptions.get(i).text());
            if (medicineFirstHeadline.size() > 0) {
                medicineInformation.put("description" + (i + 2), medicine);
            } else {
                medicineInformation.put("description" + (i + 1), medicine);
            }
        }

        //this.mysql.insertMedicineData(medicineInformation);
        return medicineInformation;
    }

    private String getShorterName(String medicineName) {

        try {
            String[] splitMedicineName = medicineName.split(" ");

            if (splitMedicineName.length > 0) {
                if (splitMedicineName.length == 3) {
                    return splitMedicineName[0] + " " + splitMedicineName[1];
                } else if (splitMedicineName.length == 2) {
                    return splitMedicineName[0];
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private String getFirstLink(Elements subLinks) {
        String subLink = "";
        try {
            subLink = (String) subLinks.get(0).toString().subSequence(subLinks.get(0).toString().indexOf("\"") + 1, subLinks.get(0).toString().indexOf(">") - 1);
            return subLink;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return subLink;
    }
}
