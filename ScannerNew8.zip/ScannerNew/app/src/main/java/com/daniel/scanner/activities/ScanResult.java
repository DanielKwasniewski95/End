package com.daniel.scanner.activities;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.daniel.scanner.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static android.text.Layout.JUSTIFICATION_MODE_INTER_WORD;

public class ScanResult extends AppCompatActivity {

    private int lastElementId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_result);

        Intent intent = getIntent();
        HashMap<String, Object> foundMedicineInformation = (HashMap<String, Object>) intent.getSerializableExtra("foundMedicineInformation");

        addTextToView(foundMedicineInformation.get("name").toString(), "name");
        for (int i = 1; i < foundMedicineInformation.size(); i++) {
            Map<String, String> description = (Map<String, String>) foundMedicineInformation.get("description" + i);
            addTextToView(description.get("headline"), "headline");
            addTextToView(description.get("content"), "content");
        }
    }

    private void addTextToView(String text, String type) {
        RelativeLayout RelativeLayoutScanResult = findViewById(R.id.scanResult);
// Create a TextView programmatically.
        //final TextView textView = new TextView(getApplicationContext());
        TextView textView = new TextView(getApplicationContext());

        textView.setId(View.generateViewId());

        // Create a LayoutParams for TextView
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                type == "name" ? RelativeLayout.LayoutParams.FILL_PARENT : RelativeLayout.LayoutParams.WRAP_CONTENT, // Width of TextView
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        if (type.equals("name")) {
            layoutParams.bottomMargin = 25;
            // Set format for TextView text
            textView.setTextColor(Color.parseColor("#419f30"));
            textView.setTextSize(22);
            textView.setTypeface(textView.getTypeface(), Typeface.BOLD_ITALIC);
            textView.setGravity(Gravity.CENTER_HORIZONTAL);
        } else if (type.equals("headline")) {
            layoutParams.addRule(RelativeLayout.BELOW, lastElementId);
            layoutParams.topMargin = 20;
            textView.setTextColor(Color.parseColor("#000000"));
            textView.setPaintFlags(textView.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            textView.setTextSize(16);
            textView.setTypeface(textView.getTypeface(), Typeface.BOLD);
        } else if (type.equals("content")) {
            layoutParams.addRule(RelativeLayout.BELOW, lastElementId);
            layoutParams.topMargin = 5;
            textView.setTextColor(Color.parseColor("#000000"));
            textView.setTextSize(14);
            textView.setJustificationMode(JUSTIFICATION_MODE_INTER_WORD);
        }

        // Apply the layout parameters to TextView widget
        textView.setLayoutParams(layoutParams);

        // Set text to display in TextView
        textView.setText(text);

        // Add newly created TextView to parent view group (RelativeLayout)
        RelativeLayoutScanResult.addView(textView);
        lastElementId = textView.getId();
    }
}
