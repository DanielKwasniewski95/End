package com.daniel.scanner.utilities;

import java.util.Map;

public class UserInput {

    public boolean doesUserFilledAllInputs(Map<String, String> map) {
        try {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                if (entry.getValue().isEmpty()) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
