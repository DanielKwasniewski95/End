package com.daniel.ElearningServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ELearningServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ELearningServerApplication.class, args);
	}

}

